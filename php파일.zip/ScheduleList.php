<?php
// 내가 신청한 과목들의 정보 가져오기(시간표관련)
	$server = "15.165.171.57";
	$username = "Maru";
	$password = "maru1234";
	$database = "sugang_db";
	$port = 3306;

	$con = mysqli_connect($server, $username, $password, $database, $port);
	mysqli_query($con, 'SET NAMES utf8');

	$stu_id = isset($_GET["stu_id"]) ? $_GET["stu_id"] : null;
	$result = mysqli_query($con, "SELECT cr.course_id, oc.course_time, p.prof_name, cr.div_id, c.course_name, c.credit
    FROM course_resistration cr
    JOIN opened_course oc ON cr.course_id = oc.course_id AND cr.div_id = oc.div_id
    JOIN professor p ON oc.prof_id = p.prof_id
    JOIN course c ON cr.course_id = c.course_id
    WHERE cr.stu_id = '$stu_id'");
	// 과목코드, 과목시간, 교수이름, 분반, 과목이름, 학점
	$response = array();
	while($row = mysqli_fetch_array($result)) {
		array_push($response, array("course_id"=>$row[0], "course_time"=>$row[1], "prof_name"=>$row[2], "div_id"=>$row[3], "course_name"=>$row[4], "credit"=>$row[5]));
	}

	echo json_encode(array("response"=>$response), JSON_UNESCAPED_UNICODE);
	mysqli_close($con);
?>