<?php
// 수강신청한 과목의 정보 조회(statistics에서 사용)
	$server = "15.165.171.57";
	$username = "Maru";
	$password = "maru1234";
	$database = "sugang_db";
	$port = 3306;

	$con = mysqli_connect($server, $username, $password, $database, $port);
	mysqli_query($con, 'SET NAMES utf8');

	$stu_id = $_GET["stu_id"];
	//$stu_id = "201901776";
	$result = mysqli_query($con, "SELECT course.course_id, opened_course.target_grade, course.course_name, course_resistration.div_id, opened_course.avail_count, opened_course.current_count, course.credit
        FROM course_resistration
        INNER JOIN opened_course ON course_resistration.course_id = opened_course.course_id AND course_resistration.div_id = opened_course.div_id
        INNER JOIN course ON opened_course.course_id = course.course_id
        WHERE course_resistration.stu_id = '$stu_id'");
	$response = array();
	//과목코드, 대상학년, 과목이름, 분반, 제한인원, 현재인원, 학점
	while($row = mysqli_fetch_array($result)){
		array_push($response, array("course_id"=>$row[0], "target_grade"=>$row[1], "course_name"=>$row[2], "div_id"=>$row[3], "avail_count"=>$row[4], "current_count"=>$row[5], "credit"=>$row[6]));
	}

	echo json_encode(array("response"=>$response), JSON_UNESCAPED_UNICODE);
	mysqli_close($con);
?>