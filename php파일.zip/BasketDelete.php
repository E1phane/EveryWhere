<?php
//장바구니에 있는 과목 삭제
$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

// 데이터베이스 연결
$con = mysqli_connect($server, $username, $password, $database, $port);

// 연결 확인
if ($con === false) {
    die("Database connection failed: " . mysqli_connect_error());
}

// POST로 전달된 데이터 수신
$stu_id = mysqli_real_escape_string($con, $_POST["stu_id"]);
$course_id = mysqli_real_escape_string($con, $_POST["course_id"]);
$div_id = mysqli_real_escape_string($con, $_POST["div_id"]);

// SQL 쿼리 준비
$statement = "DELETE FROM basket_resistration WHERE stu_id = '$stu_id' AND course_id = '$course_id' AND div_id = '$div_id'";

// SQL 쿼리 실행
if (mysqli_query($con, $statement)) {
    $response = array("success" => true);
} else {
    $response = array("success" => false);
}

// 응답 전송
echo json_encode($response);

// 데이터베이스 연결 종료
mysqli_close($con);
?>
