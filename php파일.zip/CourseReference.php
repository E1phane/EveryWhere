<?php
    $server = "15.165.171.57";
    $username = "Maru";
    $password = "maru1234";
    $database = "sugang_db";
    $port = 3306;

    $con = mysqli_connect($server, $username, $password, $database, $port);
    mysqli_query($con, 'SET NAMES utf8');

    $courseGrade = $_GET["courseGrade"];  //대상 학년
    $courseArea = $_GET["courseArea"];    //이수구분
    $courseMajor = $_GET["courseMajor"];  // 학과들
    $courseName = $_GET["courseName"];    // 과목이름

    //$courseGrade = 3;  //대상 학년
    //$courseArea = "전공선택";    //이수구분
    //$courseMajor = "전체";  // 학과들
    //$courseName = "데";    // 과목이름

    $query = "SELECT c.course_name, d.dept_name, p.prof_name, oc.course_id, oc.div_id, oc.course_time, oc.target_grade, c.classification, c.credit, oc.current_count, oc.avail_count
            FROM opened_course oc
            INNER JOIN course c ON oc.course_id = c.course_id
            INNER JOIN department d ON oc.dept_id = d.dept_id
            INNER JOIN professor p ON oc.prof_id = p.prof_id";

    $conditions = array();
    $parameters = array();
    // 경우의 수 = 학년, 이수구분, 학과이름
    if ($courseGrade && $courseGrade !== "전체") {    // 대상 학년이 "전체"가 아닐 경우
        $conditions[] = "oc.target_grade = ?";
        $parameters[] = $courseGrade;
    }

    if ($courseArea && $courseArea !== "전체") {      // 이수구분이 "전체"가 아닐 경우
        $conditions[] = "c.classification = ?";
        $parameters[] = $courseArea;
    }

    if ($courseMajor && $courseMajor !== "전체") {    // 학과이름이 "전체"가 아닐 경우
        $conditions[] = "d.dept_name = ?";
        $parameters[] = $courseMajor;
    }

    if ($courseName && $courseName !== "전체") {
    $conditions[] = "c.course_name LIKE ?";
    $parameters[] = '%' . $courseName . '%';
}

    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);    // 조건값 넣어주
    }

    $statement = mysqli_prepare($con, $query);
    if (!empty($parameters)) {
        mysqli_stmt_bind_param($statement, str_repeat("s", count($parameters)), ...$parameters);
    }

    mysqli_stmt_execute($statement);
    $result = mysqli_stmt_get_result($statement);
    $response = array();
    while($row = mysqli_fetch_array($result)){
    // 과목이름 학과이름 교수이름 과목번호 분반 강의시간 대상학년 이수구분 학점 현재인원 최대인원
        array_push($response, array("course_name"=>$row[0], "dept_name"=>$row[1], "prof_name"=>$row[2], "course_id"=>$row[3], "div_id"=>$row[4], "course_time"=>$row[5], "target_grade"=>$row[6], "classification"=>$row[7], "credit"=>$row[8], "current_count"=>$row[9], "avail_count"=>$row[10]));
    }

    echo json_encode($response);
    mysqli_close($con);
?>
