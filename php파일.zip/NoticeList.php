<?php
$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');
$result = mysqli_query($con, "SELECT * FROM NOTICE order by noticeDate DESC;");
$response = array();

while($row = mysqli_fetch_array($result)){
    array_push($response, array("noticeContent"=>$row[0], "noticeName"=>$row[1], "noticeDate"=>$row[2]));
}

echo json_encode($response);
mysqli_close($con);
?>