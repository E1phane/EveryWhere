<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');

$stu_id = isset($_POST["stu_id"]) ? $_POST["stu_id"] : "";
$stu_pw = isset($_POST["stu_pw"]) ? $_POST["stu_pw"] : "";
//$stu_id = "201901776";
//$stu_pw = "lilpa";
$statement = mysqli_prepare($con, "SELECT s.stu_id, s.stu_pw, s.stu_name, s.stu_grade, s.stu_avail_credit, d.dept_name
    FROM student s
    JOIN department d ON d.dept_id = s.dept_id
    WHERE s.stu_id = ? AND s.stu_pw = ?");
mysqli_stmt_bind_param($statement, "ss", $stu_id, $stu_pw);
mysqli_stmt_execute($statement);

mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $result_stu_id, $result_stu_pw, $result_stu_name, $result_stu_grade, $result_stu_avail_credit, $result_dept_name);

$response = array();
$response["success"] = false;

// Fetch values
while (mysqli_stmt_fetch($statement)) {
    $response["success"] = true;
    $response["stu_id"] = $result_stu_id;
    $response["stu_pw"] = $result_stu_pw;
    $response["stu_name"] = $result_stu_name;
    $response["stu_grade"] = $result_stu_grade;
    $response["stu_avail_credit"] = $result_stu_avail_credit;
    $response["dept_name"] = $result_dept_name;
}

echo json_encode($response);

mysqli_close($con);
?>
