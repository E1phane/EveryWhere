<?php
// 장바구니에 과목 추가
error_reporting(E_ALL);
ini_set('display_errors', 1);

$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');

// stu_id와 course_id의 존재 여부 확인
$stu_id = isset($_POST["stu_id"]) ? $_POST["stu_id"] : null;
$course_id = isset($_POST["course_id"]) ? $_POST["course_id"] : null;
$div_id = isset($_POST["div_id"]) ? $_POST["div_id"] : null;
//$stu_id = "201901776";
//$course_id = "0006033";
//$div_id="1";

$response["success"] = false;

if ($stu_id != null && $course_id != null && $div_id != null) {
    $statement = mysqli_prepare($con, "INSERT INTO basket_resistration (stu_id, course_id, div_id) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($statement, "ssi", $stu_id, $course_id, $div_id);

    if (mysqli_stmt_execute($statement)) {
        $response["success"] = true;
    } else {
        $response["error"] = mysqli_error($con);
    }
} else {
    $response["error"] = "stu_id and course_id are required.";
}

echo json_encode($response);
mysqli_close($con);
?>