<?php
// 장바구니 조회
$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');

$stu_id = $_GET["stu_id"];            // 학생 ID

$result = mysqli_query($con, "SELECT c.course_name, d.dept_name, p.prof_name, oc.course_id, oc.div_id, oc.course_time, oc.target_grade, c.classification, c.credit, oc.current_count, oc.avail_count 
        FROM opened_course oc
        INNER JOIN course c ON oc.course_id = c.course_id
        INNER JOIN department d ON oc.dept_id = d.dept_id
        INNER JOIN professor p ON oc.prof_id = p.prof_id
        INNER JOIN basket_resistration br ON oc.course_id = br.course_id AND oc.div_id = br.div_id
        WHERE br.stu_id = '$stu_id'");

$response = array();
while($row = mysqli_fetch_array($result)){
    // 과목이름 학과이름 교수이름 과목번호 분반 강의시간 대상학년 이수구분 학점 현재인원 최대인원
    array_push($response, array("course_name"=>$row[0], "dept_name"=>$row[1], "prof_name"=>$row[2], "course_id"=>$row[3], "div_id"=>$row[4], "course_time"=>$row[5], "target_grade"=>$row[6], "classification"=>$row[7], "credit"=>$row[8], "current_count"=>$row[9], "avail_count"=>$row[10]));
}

echo json_encode($response);
mysqli_close($con);
?>
