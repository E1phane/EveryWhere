<?php
$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$stu_id = isset($_POST["stu_id"]) ? $_POST["stu_id"] : "";
$email = isset($_POST["stu_email"]) ? $_POST["stu_email"] : "";

$statement = mysqli_prepare($con, "SELECT stu_id, stu_email FROM student WHERE stu_id = ? AND stu_email = ?");
mysqli_stmt_bind_param($statement, "ss", $stu_id, $email);
mysqli_stmt_execute($statement);

mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $result_stu_id, $result_stu_email);

$response = array();
$response["success"] = false;

// Fetch values
while (mysqli_stmt_fetch($statement)) {
    $response["success"] = true;
    $response["stu_id"] = $result_stu_id;
    $response["stu_email"] = $result_stu_email;
}

echo json_encode($response);

mysqli_close($con);
?>
