<?php
//장바구니에서 수강신청
error_reporting(E_ALL);
ini_set('display_errors', 1);

$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');

$stu_id = isset($_POST["stu_id"]) ? $_POST["stu_id"] : null;
$course_id = isset($_POST["course_id"]) ? $_POST["course_id"] : null;
$div_id = isset($_POST["div_id"]) ? $_POST["div_id"] : null;

$response = array();
$response["success"] = false;

if ($stu_id != null && $course_id != null && $div_id != null) {
    mysqli_autocommit($con, false); // 트랜잭션 시작

    // course_resistration에 추가
    $stmt_course = mysqli_prepare($con, "INSERT INTO course_resistration (stu_id, course_id, div_id) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt_course, "ssi", $stu_id, $course_id, $div_id);
    $updateStatement = mysqli_prepare($con, "UPDATE opened_course SET current_count = current_count + 1 WHERE course_id = ? AND div_id = ?");

    // basket_resistration에서 삭제
    $stmt_basket = mysqli_prepare($con, "DELETE FROM basket_resistration WHERE stu_id = ? AND course_id = ? AND div_id = ?");
    mysqli_stmt_bind_param($stmt_basket, "ssi", $stu_id, $course_id, $div_id);

    if (mysqli_stmt_execute($stmt_course) && mysqli_stmt_execute($stmt_basket)) {
        mysqli_commit($con); // 트랜잭션 커밋
        $response["success"] = true;
    } else {
        mysqli_rollback($con); // 트랜잭션 롤백
        $response["error"] = mysqli_error($con);
    }

    mysqli_autocommit($con, true); // 트랜잭션 종료
} else {
    $response["error"] = "stu_id and course_id are required.";
}

echo json_encode($response);
mysqli_close($con);
?>
