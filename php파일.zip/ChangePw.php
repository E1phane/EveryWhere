<?php
//비번 바꾸기
$server = "15.165.171.57";
$username = "Maru";
$password = "maru1234";
$database = "sugang_db";
$port = 3306;

$con = mysqli_connect($server, $username, $password, $database, $port);
mysqli_query($con, 'SET NAMES utf8');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$id = isset($_POST["id"]) ? $_POST["id"] : "";
$new_pw = isset($_POST["new_pw"]) ? $_POST["new_pw"] : "";

// Check if the current password matches the one in the database
$check_statement = mysqli_prepare($con, "SELECT stu_pw FROM student WHERE stu_id = ?");
if (!$check_statement) {
    die("Prepare failed for check_statement: " . mysqli_error($con));
}

mysqli_stmt_bind_param($check_statement, "s", $id);
mysqli_stmt_execute($check_statement);
mysqli_stmt_store_result($check_statement);

if (mysqli_stmt_num_rows($check_statement) > 0) {
    mysqli_stmt_bind_result($check_statement, $db_pw);
    mysqli_stmt_fetch($check_statement);
    // 비밀번호 일치
        $update_statement = mysqli_prepare($con, "UPDATE student SET stu_pw = ? WHERE stu_id = ?");
        if (!$update_statement) {
            die("Prepare failed for update_statement: " . mysqli_error($con));
        }

        mysqli_stmt_bind_param($update_statement, "ss", $new_pw, $id);
        mysqli_stmt_execute($update_statement);
    $response["success"] = true;
    $response["message"] = "Password updated successfully";
} else {
    $response["success"] = false;
    $response["message"] = "User not found";
}

echo json_encode($response);
mysqli_close($con);
?>
